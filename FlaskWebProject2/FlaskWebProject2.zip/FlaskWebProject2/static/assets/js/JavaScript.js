// Data Picker Initialization
$('.datepicker').datepicker();