"""
Routes and views for the flask application.
"""

from datetime import datetime
from flask import Flask, render_template, request,url_for,  flash, redirect
from FlaskWebProject2 import app
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField
from wtforms.validators import DataRequired, Length, Email, EqualTo

import pyodbc
import pandas
conx_string = "driver={SQL SERVER}; server=DESKTOP-E9RIB71\SQLEXPRESS; database=Club Elections; trusted_connection=YES;"

############################# Form Classes #######################################################
class LoginForm(FlaskForm):  
    email = StringField('Email',validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')

app.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde280ba245'
######################################################################################################333

@app.route('/', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        with pyodbc.connect(conx_string) as conx:
            cursor = conx.cursor()
            cursor.execute('SELECT COUNT(1) FROM Student WHERE Email=?', form.email.data)
            data = cursor.fetchone()
            if data[0]>0:
                cursor.execute('SELECT Student_ID FROM Student WHERE Email=?', form.email.data)
                StudentID=cursor.fetchone()[0]
                flash('You have been logged in!', 'success')
                return redirect(url_for('home'))
            elif form.email.data == 'life@admin.habib.edu.pk' and form.password.data == 'password':
                flash('You have been logged in!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html', title='Login', form=form)




@app.route('/dashboard')
def dashboard():
    """Renders the home page."""
    return render_template(
        'dashboard.html',
        title='Dashboard Page',
        year=datetime.now().year,
    )

@app.route('/election')
def election():
    return render_template('election.html')

@app.route('/candidate_approval')
def candidate_approval():
    with pyodbc.connect(conx_string) as conx:
        cursor = conx.cursor()
        query1="SELECT (select Name from Student where Student_ID=C.Candidate_StudentID),(select [Club Name] from Club where Club_ID=C.Club_ID), (SELECT DesignationRole from Position where Position_ID=C.Position_ID),(SELECT ElectionYear from Election where ElectionID=C.ElectionID) from Candidate C where isApproved=0"
        cursor.execute(query1)
        data = cursor.fetchall()
        return render_template('candidate_approval.html', data=data)

@app.route('/candidate_approved')
def candidate_approved():
    with pyodbc.connect(conx_string) as conx:
        cursor = conx.cursor()
        query1="SELECT (select Name from Student where Student_ID=C.Candidate_StudentID),(select [Club Name] from Club where Club_ID=C.Club_ID), (SELECT DesignationRole from Position where Position_ID=C.Position_ID),(SELECT ElectionYear from Election where ElectionID=C.ElectionID) from Candidate C where C.isApproved=1"
        cursor.execute(query1)
        data = cursor.fetchall()
        return render_template('candidate_approved.html', data=data)

@app.route('/candidate_display/candidate_approval/delete/<Name>')
def delete_candidate(Name):
    with pyodbc.connect(conx_string) as conx:
        cursor = conx.cursor()
        query="delete from Candidate where Candidate_StudentID=(select Student_ID from Student where Name=?)"
        cursor.execute(query,Name)
        return redirect(url_for('candidate_approval'))

@app.route('/candidate_display/candidate_approval/approve/<Name>')
def approve_candidate(Name):
    with pyodbc.connect(conx_string) as conx:
        cursor = conx.cursor()
        query="update Candidate set isApproved=1 where Candidate_StudentID=(select Student_ID from Student where Name=?)"
        cursor.execute(query,Name)
        return redirect(url_for('candidate_approval'))

@app.route('/candidate_display')
def candidate_display():
    return render_template('candidate_display.html')


@app.route('/add_club', methods=['GET', 'POST'])
def add_club():

    if request.method == 'POST':
        result=request.form
        name=result['Club Name']
        Description=result['Description']
        Patron=result['PatronName']
        ClubImagePath="static/assets/img/ClubImages/"+result['ClubImage']
        print(ClubImagePath)
        with pyodbc.connect(conx_string) as conx:
            cursor = conx.cursor()
            query1="SELECT Patron_ID from Patron where Name=?"
            cursor.execute(query1, Patron)
            ID=int(cursor.fetchall()[0][0])
            if ID!=None:
                query="insert into Club ([Club Name], [Club Description], Patron_ID, Monogram) values(?,?,?,?)"
                cursor.execute(query,name, Description, ID, ClubImagePath)
        
                return render_template('dashboard.html', message="New Club Added")

        # do stuff when the form is submitted

        # redirect to end the POST handling
        # the redirect can be to the same route or somewhere else
        #return redirect(url_for('dashboard.html'))

    # show the form, it wasn't submitted
    return render_template('add_club.html')

@app.route('/view_club')
def view_club():
    with pyodbc.connect(conx_string) as conx:
        cursor = conx.cursor()
        query1="SELECT Club_ID as Club_ID, [Club Name] as ClubName, [Club Description] as ClubDescription, PatronName= (SELECT Name from Patron where Patron_ID=C.Patron_ID), Monogram from Club C"
        cursor.execute(query1)
        rawdata = cursor.fetchall()
        data=[[column[0] for column in cursor.description],rawdata]
        return render_template('view_club.html', data=data)

@app.route('/<ClubName>', methods=['GET', 'POST'])
def edit_club(ClubName):
    if request.method == 'POST':
        result=request.form
        name=result['Club Name']
        Description=result['Description']
        Patron=result['PatronName']
        ClubImagePath="static/assets/img/ClubImages/"+result['ClubImage']
        with pyodbc.connect(conx_string) as conx:
            cursor = conx.cursor()
            query1="SELECT Patron_ID from Patron where Name=?"
            cursor.execute(query1, Patron)
            ID=int(cursor.fetchall()[0][0])
            if ID!=None:
                query="update Club set [Club Name]=? , [Club Description]=? , Patron_ID=?, Monogram=? where [Club Name]=?"
                cursor.execute(query,name, Description, ID, ClubImagePath, ClubName)
                return redirect(url_for('view_club'))
    with pyodbc.connect(conx_string) as conx:
        cursor = conx.cursor()
        query1="SELECT C.[Club Name], C.[Club Description], (select Name from Patron where Patron_ID=C.Patron_ID) FROM Club C where C.[Club Name]=?"
        cursor.execute(query1, ClubName)
        data=cursor.fetchall()[0]
        return render_template('edit_club.html', data=data)

    
    
@app.route('/view_election')
def view_election():
    with pyodbc.connect(conx_string) as conx:
        cursor = conx.cursor()
        query1="SELECT ElectionID, [ElectionYear],PollingStartDate,PollingEndDate,ValidFrom,ValidTill from Election"
        cursor.execute(query1)
        rawdata = cursor.fetchall()
        data=[[column[0] for column in cursor.description],rawdata]
        return render_template('view_election.html', data=data)

     #return render_template('add_election.html')
@app.route('/delete_election/<ID>')
def delete_election(ID):
    print(ID)
    with pyodbc.connect(conx_string) as conx:
        cursor = conx.cursor()
        query="EXEC DeleteElection @ID = ?"
        cursor.execute(query,ID)
        return redirect(url_for('view_election'))



@app.route('/add_election', methods=['GET', 'POST'])
def add_election():
    if request.method == 'POST':
        result=request.form
        Id=result['Id']
        EYear=result['Year']
        Pstart=result['PollingStart']
        Pend=result['PollingEnd']
        Vstart=result['ValidFrom']
        Vend=result['ValidTill']
        with pyodbc.connect(conx_string) as conx:
            cursor = conx.cursor()
            query="insert into Election (ElectionID, [ElectionYear],PollingStartDate,PollingEndDate,ValidFrom,ValidTill)values(?,?,cast(? as date),cast(? as date),cast(? as date),cast(? as date))"
            cursor.execute(query,Id,EYear, Pstart,Pend,Vstart,Vend)
            return render_template('dashboard.html', message="New Election Created")

        # do stuff when the form is submitted

        # redirect to end the POST handling
        # the redirect can be to the same route or somewhere else
        #return redirect(url_for('dashboard.html'))

    # show the form, it wasn't submitted
    return render_template('add_election.html')

    #return render_template('add_election.html')
@app.route('/delete_club/<ClubName>')
def delete_club(ClubName):
    print(ClubName)
    with pyodbc.connect(conx_string) as conx:
        cursor = conx.cursor()
        query="delete from Club where [Club Name]=?"
        cursor.execute(query,ClubName)
        return redirect(url_for('view_club'))



@app.route('/add_member',methods=['GET', 'POST'])
def add_member():
    if request.method == 'POST':
        result=request.form
        CN=result['Selected Club']
        SN=result['Selected Student']
        print(SN)
        Tstart=result['TenureStart']
        Tend=result['TenureEnd']
        with pyodbc.connect(conx_string) as conx:
            cursor = conx.cursor()
            query="insert into Membership values((select Student_ID from Student where Name=?), (Select Club_ID from Club where [Club Name]=?) ,cast(? as date),cast(? as date),1)"
            cursor.execute(query,SN,CN, Tstart, Tend)
            return render_template('dashboard.html', message="New Election Created")
    with pyodbc.connect(conx_string) as conx:
        cursor = conx.cursor()
        query1="SELECT [Club Name] FROM Club C"
        cursor.execute(query1)
        clubs=cursor.fetchall()
        query="SELECT Name from Student"
        cursor.execute(query)
        names=cursor.fetchall()
    return render_template('add_member.html', names=names, clubs=clubs)

@app.route('/view_member')
def view_member():
    with pyodbc.connect(conx_string) as conx:
        cursor = conx.cursor()
        query1="SELECT (select Name from Student where Student_ID=M.Student_ID),(select [Club Name] from Club where Club_ID=M.Club_ID),TenureStart,TenureEnd, isActive from Membership M"
        cursor.execute(query1)
        data = cursor.fetchall()
        return render_template('view_members.html', data=data)


#############################################################################################3
@app.route('/home')
def home():
    election_date = '18th November 2020'
    info = [{'ClubID': 1, 'ClubName': 'HU Multiverse', 'Image': 'static/multiverse.jpg'},
            {'ClubID': 2, 'ClubName': 'Entrepreneurship Club', 'Image': 'static/huec.jpg'},
            {'ClubID': 3, 'ClubName': 'HU Serve Club', 'Image': 'static/serve.jpg'} 
    ]

    return render_template('home.html', title = "Home", info = info, ED = election_date)

@app.route('/club')
def club():
    return render_template('club2.html')

@app.route('/vote')
def vote():
    return render_template('vote.html')

@app.route('/candidates')
def candidates():
    return render_template('candidates.html')

@app.route('/register')
def register():
    return render_template('register.html')
